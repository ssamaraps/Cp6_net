using Clinica.SharedKernel.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Clinica.SharedKernel.Web;

public static class ControllerExtensions
{
    public static IActionResult ToActionResult<T>(this ControllerBase controller, OperationResult<T> result)
    {
        if (!result.IsSuccess)
            return controller.StatusCode(result.StatusCode, new { code = result.ErrorCode, error = result.Error });

        if (result.StatusCode == StatusCodes.Status204NoContent)
            return controller.NoContent();

        return controller.StatusCode(result.StatusCode, result.Value);
    }
}
