namespace Clinica.Modules.Pacientes.Contracts;

public interface IPacientesApi
{
    Task<bool> ExisteAsync(string pacienteId, CancellationToken cancellationToken = default);
}
