using Clinica.Modules.Consultas.Application;
using Clinica.Modules.Consultas.Infrastructure;
using Clinica.SharedKernel.Modules;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Clinica.Modules.Consultas;

public static class ConsultasModule
{
    public static Assembly Assembly => typeof(ConsultasModule).Assembly;

    public static IServiceCollection AddConsultasModule(this IServiceCollection services)
    {
        services.AddSingleton<ConsultasMongoContext>();
        services.AddScoped<IConsultaRepository, ConsultaRepository>();
        services.AddScoped<IConsultaUseCase, ConsultaUseCase>();
        services.AddSingleton<IModuleInitializer, ConsultasInitializer>();
        return services;
    }
}
